export var iphone = 14  // named export


export default "Very less"  // default export 

// one can have only one default 