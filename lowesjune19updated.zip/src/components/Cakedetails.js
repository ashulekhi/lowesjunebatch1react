import axios from "axios"
import { useEffect } from "react"
import { useParams } from "react-router-dom"

function Cakedetails(){
    var params = useParams()
    var cakeid = params.cakeid

    useEffect(()=>{
        axios({
            url:"/cake/"+cakeid,
            method:"get"
        })
    })
    return (
        <h1>Cake details we will show here for {cakeid}</h1>
    )
}

export default Cakedetails