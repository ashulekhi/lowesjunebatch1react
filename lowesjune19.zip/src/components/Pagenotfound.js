function Pagenotfound(){
    return (
        <img src="/404.jpeg"  className="image-fluid w-50"></img>
    )
}

export default Pagenotfound