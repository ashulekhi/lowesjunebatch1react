import { BrowserRouter , Routes , Route } from "react-router-dom"
import Login from "./Login"
import Home from "./Home"
import Register from "./Register"
import Admin from "./Admin"
import Forgot from "./Forgot"
import Pagenotfound from "./Pagenotfound"
import Navbar from "./Navbar"

function Myapp(){
    return (
        <div>

           <BrowserRouter>
           <Navbar />
           <Routes>
            <Route path="/" element={<Home></Home>} />
            <Route path="/login" element={<Login></Login>} />
            <Route path="/register" element={<Register></Register>} />
            <Route path="/admin" element={<Admin></Admin>} />
            <Route path="/forgot" element={<Forgot></Forgot>} />
            <Route path="/*" element={<Pagenotfound></Pagenotfound>} />



           </Routes>
           </BrowserRouter>
        </div>
    )
}

export default Myapp