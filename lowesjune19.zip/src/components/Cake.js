import { useContext } from "react"
import { GoldContext } from "../App"

function Cake(props){
    var gold = useContext(GoldContext)
    if(props.data.eggless){
        var Label = <label>Eggless</label>
    }
    else{
        var Label  = null
    }
    return (
        <div className="card m-3" style={{width:"18rem"}}>
            <img style={{height:"15rem"}} src={props.data.image}></img>
            <label>{props.data.name}</label>
            <label>{props.data.price}</label>
            {Label}
        </div>
    )
}
export default Cake