console.log("traiing" , training)
//var x 

// x js says yesi known it is a varibale but as of now it is undefined to me 

let training = "react" // global scope 

function fifthfloor(){
    let training = "REACT" // local// functional scope
}


for(var i=0;i<10;i++){

}
for(let j=0;j<10;j++){

}

// from Es6 a new word came let introduces block scope
console.log("traii" , j)

// var vs let 
// var is global or local scope 
// let is providing block scope 


var x = 10 // from this statment js will take declaration part to the top of the code 

// let can be re declared 







