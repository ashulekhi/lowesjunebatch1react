var phone = "Samsung"

function rahul(){
     console.log("phone earlier" , phone)


    let phone = "Apple"
    console.log("phone" , phone)
}

rahul()