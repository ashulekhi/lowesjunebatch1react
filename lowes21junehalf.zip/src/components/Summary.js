export default function Summary(){
    return (
        <div>
            <h1>Checkout  Summary</h1>
        </div>
    )
}