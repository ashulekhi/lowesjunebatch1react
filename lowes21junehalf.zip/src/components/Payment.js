export default function Payment(){
    return (
        <div>
            <h1>Add Payment</h1>
        </div>
    )
}