// import { useEffect } from "react"

// export function useisLoggedIn(){

//     var [isloggedin,setIsloggedin] = useState()

//     useEffect(()=>{
//         // make a api call here to check the login status of user 
//         // in response of api setIsloggedin to true is user is loggedin still
//         // once u set it to true

//     })

//     return isloggedin

// }
