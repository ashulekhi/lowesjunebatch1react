export var iphone = 14  // named export


export function getUsers(){

}

export var users = []

export var userdetails = {}

export default "Very less"  // default export 

// one can have only one default 